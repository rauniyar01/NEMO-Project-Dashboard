import express from "express";
//import data from "../data";
import axios from 'axios';
var querystring = require('querystring');
import bodyParser from "body-parser";

const classificationRouter = express.Router();
classificationRouter.use(bodyParser.json()); // to use body object in requests

classificationRouter.post("/", (req, res) => {

  // var options = {
  //       host: '10.140.140.7',
  //       port: 5007,
  //       path: '/emitterMessage',
  //       method: 'POST',
  //       headers: {
  //           'Content-Type': 'application/json',
  //       }
  //   };	
  var Noise_Res = req.body.classificationMessage.classification.sound.result;
  var Exhaust_Res;	
  var result;
  var pM = req.body.classificationMessage.classification.exhaust.pM_emLevel;
  var nOX = req.body.classificationMessage.classification.exhaust.nOX_emLevel;
  var cO = req.body.classificationMessage.classification.exhaust.cO_emLevel;
  var hC = req.body.classificationMessage.classification.exhaust.hC_emLevel;
  if(pM === 'high' || 'nOX' === 'high' || cO === 'high' || hC === 'high'){
  	Exhaust_Res = 'high';	
  } else{
  	Exhaust_Res = 'low';
  }

  if(Noise_Res === 'high' && Exhaust_Res === 'low'){
  	result = 1;
  }	else if(Noise_Res === 'low' && Exhaust_Res === 'low'){
    result = 0; 
  } else if(Noise_Res === 'low' && Exhaust_Res === 'high'){
    result = 2;
  } else{
  	result = 3;
  }

  var Data = querystring.stringify({
  	messageId: req.body.classificationMessage.v2xid,
    resultId: result
  });
  axios({
  	method: 'post',
  	url: 'http://localhost:4005/emitterMessage',
  	data: {
  			messageId: req.body.classificationMessage.v2xid,
    		resultId: result
  		},
   }).then(function ({data}) {
      console.log('Success ' + JSON.stringify(data))
    })
    .catch(function (error) {
      console.log('Error ' + error.message)
    });
  res.status(200).send({
    success: 'true',
    message: 'Emitter Message',
    messageId: req.body.classificationMessage.v2xid,
    resultId: result,
    //sound_result: Noise_Res,
    //data: req.body,
  });
});


module.exports = classificationRouter;
