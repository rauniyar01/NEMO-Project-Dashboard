const data = [
  {
    "classificationMessage": {
      "v2xid": "123e4567-e89b-12d3-a456-426614174000",
      "classification": {
        "id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
        "siteId": "Valencia",
        "vehicleId": "string",
        "passbyId": "string",
        "dateTime": "2020-01-01T11:11:11.999Z",
        "passbyDateTime": "2020-01-01T11:11:11.999Z",
        "sound": {
          "result": "low",
          "model": "NEMO SOUND V1.2"
        },
        "exhaust": {
          "pM_emLevel": "low",
          "nOX_emLevel": "low",
          "cO_emLevel": "low",
          "hC_emLevel": "low",
          "model": "NEMO EXHAUST V2.5"
        },
        "classificationType": "road"
      }
    }
  }
];
module.exports = data;
