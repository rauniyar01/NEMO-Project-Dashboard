# Swagger-in-NodeJS
With this project you can test your REST-APIs in a server built with Nodejs using swaggerUI

Just install related npm packages with command "npm install", 
and run the server with commend "npm start" 
and then the swagger UI will be running on http://localhost:4001/api-docs

And you can read this article to understand better how to work this project:
https://js.plainenglish.io/how-to-implement-and-use-swagger-in-nodejs-d0b95e765245
