import express from "express";
import cors from "cors";
import morgan from "morgan";
import dotenv from "dotenv";
import classificationRouter from "../Routes/classification";
import swaggerUI from "swagger-ui-express";
import swaggerJsDoc from "swagger-jsdoc";

const PORT = process.env.PORT || 4005;
dotenv.config();

const app = express();

app.use(morgan("dev"));
app.use(cors());

app.use("/emitterMessage", classificationRouter);

app.listen(PORT, () => console.log(`Server runs on port ${PORT}`));
