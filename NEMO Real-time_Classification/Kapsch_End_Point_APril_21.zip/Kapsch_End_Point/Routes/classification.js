import express from "express";
//import data from "../data";
import bodyParser from "body-parser";

const classificationRouter = express.Router();
classificationRouter.use(bodyParser.json()); // to use body object in requests

classificationRouter.post("/", (req, res) => {
	res.status(200).send({
    success: 'true',
    message: 'Emitter Message',
    data: req.body,
    //console.log(data),
    //sound_result: Noise_Res,
    //data: req.body,
  });
console.log(req.body);
});


module.exports = classificationRouter;
